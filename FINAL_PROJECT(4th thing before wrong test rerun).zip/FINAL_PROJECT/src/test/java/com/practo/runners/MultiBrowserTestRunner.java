package com.practo.runners;

import Utils.WriteToExcel;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class MultiBrowserTestRunner {
    public static void main(String[] args) {
        String[] browsers = {"chrome", "edge"};
        String[] sheets = {
            "TestCase3_InvalidForm",
            "TestCase2_TopCities",
            "TestCase1_HospitalFilter"
        };

        for (String browser : browsers) {
            System.setProperty("browser", browser);

            // Log to all sheets
            for (String sheet : sheets) {
                WriteToExcel.log(sheet, "==============================");
                WriteToExcel.log(sheet, "Running tests on: " + browser);
                WriteToExcel.log(sheet, "==============================");
            }

            Result result = JUnitCore.runClasses(TestRunner.class);

            for (Failure failure : result.getFailures()) {
                for (String sheet : sheets) {
                    WriteToExcel.log(sheet, "Failure: " + failure.toString());
                }
            }

            for (String sheet : sheets) {
                WriteToExcel.log(sheet, "Tests run: " + result.getRunCount());
                WriteToExcel.log(sheet, "Tests failed: " + result.getFailureCount());
                WriteToExcel.log(sheet, "Tests ignored: " + result.getIgnoreCount());
                WriteToExcel.log(sheet, "Successful: " + result.wasSuccessful());
            }
        }
    }
}

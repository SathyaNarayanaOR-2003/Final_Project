package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class CorporateWellnessPage {
    WebDriver driver;
    WebDriverWait wait;

    public CorporateWellnessPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    By nameField = By.name("name");
    By organizationField = By.name("organizationName");
    By contactField = By.name("contactNumber");
    By emailField = By.name("officialEmailId");
    By sizeDropdown = By.name("organizationSize");
    By interestDropdown = By.name("interestedIn");
    By scheduleButton = By.xpath("//button[contains(text(),'Schedule a demo')]");

    public void fillFormWithInvalidData() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(nameField)).sendKeys("");
        driver.findElement(organizationField).sendKeys("");
        driver.findElement(contactField).sendKeys("7904115");
        driver.findElement(emailField).sendKeys("Sathya@gmail");
    }

    public void selectDropdowns() {
        WebElement sizeDrop = wait.until(ExpectedConditions.elementToBeClickable(sizeDropdown));
        sizeDrop.click();
        sizeDrop.sendKeys("501-1000");

        WebElement interestDrop = wait.until(ExpectedConditions.elementToBeClickable(interestDropdown));
        interestDrop.click();
        interestDrop.sendKeys("Referring someone");
    }

    public void triggerValidationManually() {
        driver.findElement(nameField).click();
        driver.findElement(organizationField).click();
        driver.findElement(contactField).click();
        driver.findElement(emailField).click();
        driver.findElement(sizeDropdown).click();
    }

    public void captureErrorMessages() {
        List<WebElement> errorMessages = driver.findElements(By.className("error-message"));
        if (errorMessages.isEmpty()) {
            System.out.println("No error messages found.");
        } else {
            for (WebElement error : errorMessages) {
                System.out.println("Error: " + error.getText());
            }
        }
    }

    public boolean isScheduleButtonEnabled() {
        WebElement button = wait.until(ExpectedConditions.presenceOfElementLocated(scheduleButton));
        return button.isEnabled();
    }

    public void forceClickScheduleButton() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.querySelector(\"button[disabled]\").removeAttribute('disabled');");
        js.executeScript("document.querySelector(\"button\").click();");
        System.out.println("Forced click on Schedule button.");
    }

    public void logInvalidFields() {
        System.out.println("Checking for invalid fields...");
        WebElement name = driver.findElement(nameField);
        WebElement org = driver.findElement(organizationField);
        WebElement contact = driver.findElement(contactField);
        WebElement email = driver.findElement(emailField);

        if (isEmpty(name)) System.out.println("Empty Name");
        if (isEmpty(org)) System.out.println("Empty Organization Name");
        if (isInvalidPhone(contact)) System.out.println("Invalid Contact Number");
        if (isInvalidEmail(email)) System.out.println("Invalid Email ID");
    }

    private boolean isEmpty(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || value.trim().isEmpty();
    }

    private boolean isInvalidPhone(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || !value.matches("\\d{10}");
    }

    private boolean isInvalidEmail(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || !value.matches("^[\\w.-]+@[\\w.-]+\\.\\w{2,}$");
    }
}

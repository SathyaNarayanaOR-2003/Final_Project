package Pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PractoHospitalScraper {
    WebDriver driver;
    WebDriverWait wait;
    String mainWindow;
    List<String> filteredHospitals = new ArrayList<>();

    // Constructor
    public PractoHospitalScraper(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void openPage() {
        driver.get("https://www.practo.com/");
        driver.manage().window().maximize();
        mainWindow = driver.getWindowHandle();
    }

    public void search(String city) {
        try {
            WebElement cityInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search location']")));
            cityInput.clear();
            cityInput.sendKeys(city);    
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'" + city + "')]"))).click();
            WebElement search = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div/input")));
            search.clear();
            search.sendKeys("Hospital");
            WebElement hospitalOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div[2]/div[1]/div[4]/span[1]/div")));
            new Actions(driver).moveToElement(hospitalOption).click().perform();
            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[@class='line-1']")));
        } catch(Exception e) {
            System.out.println("Error: "+e.getMessage());
        }
    }

    public void filterHospitals() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        int previousSize = 0;
        List<WebElement> hospitals;
        try {
            for (int i = 0; i < 50; i++) {
                js.executeScript("window.scrollBy(0, 1000)");
                hospitals = driver.findElements(By.xpath("//h2[@class='line-1']"));
                if (hospitals.size() == previousSize) break;
                previousSize = hospitals.size();
            }
        } catch(Exception e) {
            System.out.println(e.getMessage());
        }

        List<WebElement> hospitals247 = driver.findElements(By.xpath("//span[contains(text(),'Open 24x7')]//ancestor::div[2]//h2[@class='line-1']"));
        for (WebElement hospital : hospitals247) {
            String name = hospital.getText();
            try {
                hospital.click();
                Set<String> windows = driver.getWindowHandles();
                for (String handle : windows) {
                    if (!handle.equals(mainWindow)) {
                        driver.switchTo().window(handle);
                        break;
                    }
                }

                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("bubbles")));
                WebElement ratingElement = driver.findElement(By.xpath("//span[@class='common__star-rating__value']"));
                double rating = Double.parseDouble(ratingElement.getText());
                if (rating > 3.5) {
                    WebElement readMore = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='pure-u-1']//span[contains(@class,'u-bold')]/span")));
                    readMore.click();

                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Amenities')]")));
                    boolean hasParking = driver.findElements(By.xpath("//span[contains(text(),'Parking')]")).size() > 0;

                    if (hasParking) {
                        filteredHospitals.add(name);
                    } 
                }
            } catch (Exception e) {
                System.out.println("Error checking parking for: " + name);
            } finally {
                driver.close();
                driver.switchTo().window(mainWindow);
            }
        }
    }

    public void printHospitalsWithRating() {
        System.out.println("Printing and Writing");
        for(String str : filteredHospitals) {
            System.out.println(str);
        }
        driver.quit();
        //writeExcel();
    }
}

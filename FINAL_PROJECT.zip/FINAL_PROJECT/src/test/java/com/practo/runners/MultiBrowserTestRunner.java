package com.practo.runners;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class MultiBrowserTestRunner {
    public static void main(String[] args) {
        String[] browsers = {"chrome", "edge"};

        for (String browser : browsers) {
            System.setProperty("browser", browser);
            System.out.println("\n==============================");
            System.out.println("Running tests on: " + browser);
            System.out.println("==============================");

            Result result = JUnitCore.runClasses(TestRunner.class);

            for (Failure failure : result.getFailures()) {
                System.out.println("Failure: " + failure.toString());
            }

            System.out.println("Tests run: " + result.getRunCount());
            System.out.println("Tests failed: " + result.getFailureCount());
            System.out.println("Tests ignored: " + result.getIgnoreCount());
            System.out.println("Successful: " + result.wasSuccessful());
        }
    }
}

package com.practo.stepdefinitions;

import Pages.DiagnosticsPage;
import Utils.Hooks;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

import java.time.Duration;
import java.util.List;

public class DiagnosticsSteps {
    DiagnosticsPage diagnosticsPage;

    @Given("I navigate to the diagnostics page")
    public void i_navigate_to_diagnostics_page() {
        Hooks.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        Hooks.getDriver().get("https://www.practo.com");

        diagnosticsPage = new DiagnosticsPage(Hooks.getDriver());
        diagnosticsPage.navigateToLabTests();
    }

    @Then("I should see a list of top cities")
    public void i_should_see_list_of_top_cities() {
        List<String> cities = diagnosticsPage.getTopCities();
        System.out.println("Top Cities:");
        cities.forEach(System.out::println);
    }
}

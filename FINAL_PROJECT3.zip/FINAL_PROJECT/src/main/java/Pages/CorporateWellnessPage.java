package Pages;

import org.openqa.selenium.By;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import Utils.ReadExcel;
import Utils.WriteToExcel;

public class CorporateWellnessPage {
    WebDriver driver;
    WebDriverWait wait;

    public CorporateWellnessPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    By nameField = By.name("name");
    By organizationField = By.name("organizationName");
    By contactField = By.name("contactNumber");
    By emailField = By.name("officialEmailId");
    By sizeDropdown = By.name("organizationSize");
    By interestDropdown = By.name("interestedIn");
    By scheduleButton = By.xpath("//button[contains(text(),'Schedule a demo')]");
    
    String[] data = null;
    public void ReadExcelData(String filepath)
    {
        try
        {
        	data = ReadExcel.readFormData(filepath);
        }
        catch(IOException e)
        {
        	e.printStackTrace();
        }
    }

    public void fillFormWithInvalidData() {
    	ReadExcelData("src\\test\\resources\\TestInput\\CorporateWellnessPageData.xlsx");
        wait.until(ExpectedConditions.visibilityOfElementLocated(nameField)).sendKeys(data[0]);
        driver.findElement(organizationField).sendKeys(data[1]);
        driver.findElement(contactField).sendKeys(data[2]);
        driver.findElement(emailField).sendKeys(data[3]);
    }

    public void selectDropdowns() {
        WebElement sizeDrop = wait.until(ExpectedConditions.elementToBeClickable(sizeDropdown));
        sizeDrop.click();
        sizeDrop.sendKeys(data[4]);

        WebElement interestDrop = wait.until(ExpectedConditions.elementToBeClickable(interestDropdown));
        interestDrop.click();
        interestDrop.sendKeys(data[5]);
    }

    public void triggerValidationManually() {
        driver.findElement(nameField).click();
        driver.findElement(organizationField).click();
        driver.findElement(contactField).click();
        driver.findElement(emailField).click();
        driver.findElement(sizeDropdown).click();
    }

    public void captureErrorMessages() {
        List<WebElement> errorMessages = driver.findElements(By.className("error-message"));
        if (errorMessages.isEmpty()) {
            WriteToExcel.log("TestCase3_InvalidForm", "No error messages found.");
        } else {
            for (WebElement error : errorMessages) {
                WriteToExcel.log("TestCase3_InvalidForm", "Error: " + error.getText());
            }
        }
    }

    public boolean isScheduleButtonEnabled() {
        WebElement button = wait.until(ExpectedConditions.presenceOfElementLocated(scheduleButton));
        return button.isEnabled();
    }

    public void forceClickScheduleButton() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.querySelector(\"button[disabled]\").removeAttribute('disabled');");
        js.executeScript("document.querySelector(\"button\").click();");
        WriteToExcel.log("TestCase3_InvalidForm", "Forced click on Schedule button.");
    }

    public void logInvalidFields() {
        WriteToExcel.log("TestCase3_InvalidForm", "Checking for invalid fields...");
        WebElement name = driver.findElement(nameField);
        WebElement org = driver.findElement(organizationField);
        WebElement contact = driver.findElement(contactField);
        WebElement email = driver.findElement(emailField);

        if (isEmpty(name)) WriteToExcel.log("TestCase3_InvalidForm", "Empty Name");
        if (isEmpty(org)) WriteToExcel.log("TestCase3_InvalidForm", "Empty Organization Name");
        if (isInvalidPhone(contact)) WriteToExcel.log("TestCase3_InvalidForm", "Invalid Contact Number");
        if (isInvalidEmail(email)) WriteToExcel.log("TestCase3_InvalidForm", "Invalid Email ID");
    }

    private boolean isEmpty(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || value.trim().isEmpty();
    }

    private boolean isInvalidPhone(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || !value.matches("\\d{10}");
    }

    private boolean isInvalidEmail(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || !value.matches("^[\\w.-]+@[\\w.-]+\\.\\w{2,}$");
    }
}









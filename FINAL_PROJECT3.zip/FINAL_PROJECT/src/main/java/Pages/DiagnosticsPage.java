package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

import Utils.WriteToExcel;

public class DiagnosticsPage {
    WebDriver driver;

    public DiagnosticsPage(WebDriver driver) {
        this.driver = driver;
    }

    // Navigate to Surgeries and Lab Tests section
    public void navigateToLabTests() {
        WebElement surgeries = driver.findElement(By.xpath("//div[text()='Surgeries']"));
        surgeries.click();

        WebElement labTests = driver.findElement(By.xpath("//div[text()='Lab Tests']"));
        labTests.click();
    }

    // Extract top cities listed under Diagnostics
    public List<String> getTopCities() {
        List<WebElement> cities = driver.findElements(By.cssSelector("ul > li > div.u-margint--standard"));
        List<String> cityNames = cities.stream().map(WebElement::getText).collect(Collectors.toList());

        WriteToExcel.log("TestCase2_TopCities", "Top Cities:");
        cityNames.forEach(city -> WriteToExcel.log("TestCase2_TopCities", city));

        return cityNames;
    }
}





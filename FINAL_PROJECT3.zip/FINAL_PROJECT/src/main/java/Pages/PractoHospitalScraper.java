package Pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import Utils.WriteToExcel;

import java.time.Duration;
import java.util.*;

public class PractoHospitalScraper {
    WebDriver driver;
    WebDriverWait wait;
    String mainWindow;
    List<String> filteredHospitals = new ArrayList<>();

    public PractoHospitalScraper(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void openPage() {
        driver.get("https://www.practo.com/");
        driver.manage().window().maximize();
        mainWindow = driver.getWindowHandle();
        WriteToExcel.log("TestCase1_HospitalFilter", "Opened Practo homepage.");
    }

    public void search(String city) {
        try {
            WriteToExcel.log("TestCase1_HospitalFilter", "Searching for hospitals in: " + city);
            WebElement cityInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search location']")));
            cityInput.clear();
            cityInput.sendKeys(city);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'" + city + "')]"))).click();

            WebElement search = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div/input")));
            search.clear();
            search.sendKeys("Hospital");

            WebElement hospitalOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div[2]/div[1]/div[4]/span[1]/div")));
            new Actions(driver).moveToElement(hospitalOption).click().perform();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[@class='line-1']")));
        } catch (Exception e) {
            WriteToExcel.log("TestCase1_HospitalFilter", "Error during search: " + e.getMessage());
        }
    }

    public void filterHospitals() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        int previousSize = 0;
        List<WebElement> hospitals;

        try {
            for (int i = 0; i < 50; i++) {
                js.executeScript("window.scrollBy(0, 1000)");
                hospitals = driver.findElements(By.xpath("//h2[@class='line-1']"));
                if (hospitals.size() == previousSize) break;
                previousSize = hospitals.size();
            }
        } catch (Exception e) {
            WriteToExcel.log("TestCase1_HospitalFilter", "Scrolling error: " + e.getMessage());
        }

        List<WebElement> hospitals247 = driver.findElements(By.xpath("//span[contains(text(),'Open 24x7')]//ancestor::div[2]//h2[@class='line-1']"));
        for (WebElement hospital : hospitals247) {
            String name = hospital.getText();
            try {
                hospital.click();
                Set<String> windows = driver.getWindowHandles();
                for (String handle : windows) {
                    if (!handle.equals(mainWindow)) {
                        driver.switchTo().window(handle);
                        break;
                    }
                }

                wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("bubbles")));
                WebElement ratingElement = driver.findElement(By.xpath("//span[@class='common__star-rating__value']"));
                double rating = Double.parseDouble(ratingElement.getText());

                if (rating > 3.5) {
                    WebElement readMore = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='pure-u-1']//span[contains(@class,'u-bold')]/span")));
                    readMore.click();

                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Amenities')]")));
                    boolean hasParking = driver.findElements(By.xpath("//span[contains(text(),'Parking')]")).size() > 0;

                    if (hasParking) {
                        filteredHospitals.add(name);
                        WriteToExcel.log("TestCase1_HospitalFilter", "Added hospital: " + name);
                    }
                }
            } catch (Exception e) {
                WriteToExcel.log("TestCase1_HospitalFilter", "Error checking parking for: " + name);
            } finally {
                driver.close();
                driver.switchTo().window(mainWindow);
            }
        }
    }

    public void printHospitalsWithRating() {
        WriteToExcel.log("TestCase1_HospitalFilter", "Printing and Writing");
        for (String str : filteredHospitals) {
            WriteToExcel.log("TestCase1_HospitalFilter", str);
        }
        driver.quit();
    }
}

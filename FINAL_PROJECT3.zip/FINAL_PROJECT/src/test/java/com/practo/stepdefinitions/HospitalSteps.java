package com.practo.stepdefinitions;

import io.cucumber.java.en.*;
import Pages.PractoHospitalScraper;
import Utils.Hooks;
import org.openqa.selenium.WebDriver;

public class HospitalSteps {

    WebDriver driver = Hooks.getDriver(); // Get driver from Hooks
    PractoHospitalScraper hp = new PractoHospitalScraper(driver); // Pass driver to scraper

    @Given("I open the Practo website")
    public void openPracto() {
        hp.openPage();
    }

    @When("I search for hospitals in {string}")
    public void searchHospitals(String city) {
        hp.search(city);
    }

    @And("I filter hospitals that offer \"24x7\" service and rating greater than 3.5")
    public void filterHospitals() {
        hp.filterHospitals();
    }

    @Then("I print the filtered hospital list")
    public void printHospitalsWithRating() {
        hp.printHospitalsWithRating();
    }
}

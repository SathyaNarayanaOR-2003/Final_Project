package com.practo.utils;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.AssumptionViolatedException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;

public class Hooks {
    public static WebDriver driver;
    private static final Logger logger = LogManager.getLogger(Hooks.class);

    @Before
    public void setUp() {
        String browser = System.getProperty("browser", "chrome"); // default to chrome
        driver = DriverSetup.initializeDriver(browser);
        driver.manage().window().maximize();

        logger.info("==============================");
        logger.info("Running tests on: " + browser);
        logger.info("==============================");
    }

    @After
    public void tearDown(Scenario scenario) {
        logger.info("Scenario completed: " + scenario.getName());
        logger.info("Status: " + scenario.getStatus());

        // Capture screenshot on failure
        if (scenario.isFailed()) {
            final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.attach(screenshot, "image/png", "Failure Screenshot");

            // Log to Extent Report
            ExtentCucumberAdapter.addTestStepLog("Scenario failed: " + scenario.getName());
        }

        if (driver != null) {
            driver.quit();
            logger.info("Driver closed.");
        }

        if (scenario.isFailed() && RetryTracker.shouldRetry()) {
            RetryTracker.increment();
            logger.warn("Retrying scenario: " + scenario.getName() + " | Attempt: " + RetryTracker.getRetryCount());
            throw new AssumptionViolatedException("Retrying scenario due to failure.");
        } else {
            RetryTracker.reset();
        }
    }

    public static WebDriver getDriver() {
        return driver;
    }
}

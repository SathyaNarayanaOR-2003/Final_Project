package Pages;


import java.time.Duration;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utils.WriteToExcel;


public class RatingFinder {
//	xpath = "//table[@class='hospital-table']//td[text()='Ratings']/following-sibling::td[3]";
	WebDriver driver;
    WebDriverWait wait;
    String mainWindow;
    boolean isRating;
    
    private static final Logger logger = LogManager.getLogger(RatingFinder.class);
    
    public RatingFinder(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        logger.info("RatingFinder initialized.");
    }
    
    public void open() {
        driver.get("https://www.practo.com/");
        driver.manage().window().maximize();
        mainWindow = driver.getWindowHandle();
//        WriteToExcel.log("TestCase1_HospitalFilter", "Opened Practo homepage.");
//        logger.info("Opened Practo homepage.");
    }
    
    public void searchhospital(String city) {
        try {
            WriteToExcel.log("TestCase0_MaxRatingFinder", "Searching for hospitals in: " + city);
            logger.info("Searching for hospitals in: " + city);

            WebElement cityInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search location']")));
            cityInput.clear();
            Thread.sleep(1000);
            cityInput.sendKeys(city);
            wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'" + city + "')]"))).click();

            WebElement search = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div/input")));
            search.clear();
            search.sendKeys("Hospital");
            Thread.sleep(2000);
            WebElement hospitalOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div[2]/div[1]/div[4]/span[1]/div")));
            new Actions(driver).moveToElement(hospitalOption).click().perform();

            wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[@class='line-1']")));
        } catch (Exception e) {
            WriteToExcel.log("TestCase0_MaxRatingFinder", "Error during search: " + e.getMessage());
            logger.error("Error during search: " + e.getMessage(), e);
        }
    }
    
//    @SuppressWarnings("deprecation")
	public void findrating(String city, double threshold) {
//    	try {
    		WriteToExcel.log("TestCase0_MaxRatingFinder", "Checking for rating above 4.5: " + city);
            logger.info("Checking for rating above 4.5 for hospitals in " + city);
            
            WebElement rating = driver.findElement(By.xpath("//table[@class='hospital-table']//td[text()='Ratings']/following-sibling::td[3]"));
            Double ratingValue = Double.parseDouble(rating.getText());

            Assert.assertTrue("TestCase0_MaxRatingFinder | Rating is above 4.5: " + ratingValue, ratingValue > threshold);

            
            isRating = true;
//            System.out.println();
        	WriteToExcel.log("TestCase0_MaxRatingFinder", "Rating: " + ratingValue);
            logger.info("Max Rating: " + ratingValue);
            
//    	}
//    	catch(AssertionError e) {
//            WriteToExcel.log("TestCase0_MaxRatingFinder", "Error finding Rating above 4.5: " + e.getMessage());
//    		isRating = false;
//    		System.out.println("Error finding rating above 4.5 in "+city);
//    	}
    }
    
    public void result() {
    	if(isRating) {
    		System.out.println("The rating is above 4.5");
    		WriteToExcel.log("TestCase0_MaxRatingFinder", "Max Rating is above 4.5: ");
            logger.info("Max Rating is above 4.5");
    	}
    	else {
    		System.out.println("The rating is not above 4.5");
    		WriteToExcel.log("TestCase0_MaxRatingFinder", "Max Rating is not above 4.5: ");
            logger.info("Max Rating is not above 4.5");
    	}
    }
    
    
}

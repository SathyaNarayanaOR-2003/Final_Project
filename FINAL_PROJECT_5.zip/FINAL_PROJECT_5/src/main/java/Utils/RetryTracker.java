package Utils;

public class RetryTracker {
    private static int retryCount = 0;
    private static final int maxRetries = 3;

    public static boolean shouldRetry() {
        return retryCount < maxRetries;
    }

    public static void increment() {
        retryCount++;
    }

    public static void reset() {
        retryCount = 0;
    }

    public static int getRetryCount() {
        return retryCount;
    }
}

package com.practo.stepdefinitions;

import Pages.CorporateWellnessPage;
import Pages.HomePage;
import Utils.Hooks;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CorporateSteps {
    CorporateWellnessPage wellnessPage;

    @Given("I open the Corporate Wellness form")
    public void i_open_the_corporate_wellness_form() {
        Hooks.getDriver().get("https://www.practo.com");

        HomePage homePage = new HomePage(Hooks.getDriver());
        homePage.goToCorporateWellness();

        wellnessPage = new CorporateWellnessPage(Hooks.getDriver());
    }

    @When("I fill invalid details and submit")
    public void i_fill_invalid_details_and_submit() {
        wellnessPage.fillFormWithInvalidData();
        wellnessPage.selectDropdowns();
        wellnessPage.triggerValidationManually();
        wellnessPage.forceClickScheduleButton();
    }

    @Then("I should see validation error messages")
    public void i_should_see_validation_error_messages() {
        wellnessPage.captureErrorMessages();
        wellnessPage.logInvalidFields();
    }
}

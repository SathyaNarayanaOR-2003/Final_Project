package com.practo.stepdefinitions;

import io.cucumber.java.en.*;
import Pages.RatingFinder;
import Utils.Hooks;
import org.openqa.selenium.WebDriver;

public class FindRatingSteps {

    WebDriver driver = Hooks.getDriver(); // Get driver from Hooks
    RatingFinder rf = new RatingFinder(driver); // Pass driver to scraper

    @Given("I open the website")
    public void open() {
//        Hooks.getDriver().get("https://www.practo.com");
//    	RatingFinder = new RatingFinder(Hooks.getDriver());
        rf.open();
    }

    @When("I search for hospital in {string}")
    public void i_check_for_rating_in_coimbatore(String city) {
        rf.searchhospital(city);
//        throw new io.cucumber.java.PendingException();
    }

    @Then("I check for rating above {double} in {string}")
    public void checkRating(Double ratingThreshold,String city) {
        rf.findrating(city, ratingThreshold);
    }

    @Then("I print the result")
    public void printRatingResult() {
        rf.result();
    }
}

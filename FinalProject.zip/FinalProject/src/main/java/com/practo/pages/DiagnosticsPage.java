package com.practo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class DiagnosticsPage {
    WebDriver driver;

    public DiagnosticsPage(WebDriver driver) {
        this.driver = driver;
    }

    // Navigate to Surgeries and Lab Tests section
    public void navigateToLabTests() {
        WebElement surgeries = driver.findElement(By.xpath("//div[text()='Surgeries']"));
        surgeries.click();

        WebElement labTests = driver.findElement(By.xpath("//div[text()='Lab Tests']"));
        labTests.click();
    }

    // Extract top cities listed under Diagnostics
    public List<String> getTopCities() {
        List<WebElement> cities = driver.findElements(By.cssSelector("ul > li > div.u-margint--standard"));
        return cities.stream().map(WebElement::getText).collect(Collectors.toList());
    }
}

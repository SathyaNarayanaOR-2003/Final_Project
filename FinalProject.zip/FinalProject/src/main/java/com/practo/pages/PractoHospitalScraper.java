package com.practo.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.Set;

public class PractoHospitalScraper {
    WebDriver driver;
    WebDriverWait wait;
    String mainWindow;

    public PractoHospitalScraper(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    public void filterAndExtract() throws InterruptedException {
        driver.get("https://www.practo.com/");
        driver.manage().window().maximize();

        WebElement cityInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search location']")));
        cityInput.clear();
        cityInput.sendKeys("Bangalore");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[contains(text(),'Bangalore')]")).click();

        WebElement search = driver.findElement(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div/input"));
        search.clear();
        search.sendKeys("Hospital");
        Thread.sleep(2000);

        Actions action = new Actions(driver);
        WebElement hospitalOption = driver.findElement(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div[2]/div[1]/div[4]/span[1]/div"));
        action.moveToElement(hospitalOption).perform();
        Thread.sleep(1000);
        action.click().perform();

        Thread.sleep(2000);
        mainWindow = driver.getWindowHandle();

        List<WebElement> hospitals247 = driver.findElements(By.xpath("//span[contains(text(),'Open 24x7')]//ancestor::div[2]//h2[@class='line-1']"));
        System.out.println("Hospitals that contain parking, rating > 3.5, open 24/7:\n");

        for (WebElement hospital : hospitals247) {
            filterParking(hospital);
            driver.switchTo().window(mainWindow);
        }

        Thread.sleep(2000);
        check24x7();
        Thread.sleep(5000);
    }

    public void filterParking(WebElement ele) {
        String hosp = ele.getText();
        ele.click();

        Set<String> windows = driver.getWindowHandles();
        for (String handle : windows) {
            if (!handle.equals(mainWindow)) {
                driver.switchTo().window(handle);
            }
        }

        try {
            WebElement readMore = driver.findElement(By.xpath("//*[@class='pure-u-1']//span/span"));
            readMore.click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Amenities')]")));
            boolean allow = driver.findElement(By.xpath("//span[contains(text(),'Parking')]")).isDisplayed();
            if (allow) {
                System.out.println(hosp);
            }
            driver.close();
        } catch (Exception e) {
            System.out.println("Error checking parking for: " + hosp);
        }
    }

    public void check24x7() {
        List<WebElement> hospitals = driver.findElements(By.xpath("//div[contains(@class,'c-estb-info')]"));
        int count = 0;

        for (WebElement hospital : hospitals) {
            if (count >= 30) break;

            try {
                String name = hospital.findElement(By.tagName("h2")).getText();
                String ratingText = hospital.findElement(By.xpath(".//span[contains(@class,'rating') or contains(@class,'u-')][1]")).getText();
                double rating = Double.parseDouble(ratingText);

                if (rating > 3.5) {
                    System.out.println(++count + ". " + name + " (Rating: " + rating + ")");
                }
            } catch (Exception e) {
                // Skip if rating or name not found
            }
        }
    }
}

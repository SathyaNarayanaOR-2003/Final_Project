package com.practo.stepdefinitions;

import com.practo.pages.CorporateWellnessPage;
import com.practo.pages.HomePage;
import com.practo.utils.DriverSetup;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class CorporateSteps {
    WebDriver driver;
    CorporateWellnessPage wellnessPage;

    @Given("I open the Corporate Wellness form")
    public void i_open_the_corporate_wellness_form() {
        driver = DriverSetup.initializeDriver("chrome");
        driver.get("https://www.practo.com");

        HomePage homePage = new HomePage(driver);
        homePage.goToCorporateWellness();

        wellnessPage = new CorporateWellnessPage(driver);
    }

    @When("I fill invalid details and submit")
    public void i_fill_invalid_details_and_submit() {
        wellnessPage.fillFormWithInvalidData();
        wellnessPage.selectDropdowns();
        wellnessPage.triggerValidationManually();
        wellnessPage.forceClickScheduleButton();
    }

    @Then("I should see validation error messages")
    public void i_should_see_validation_error_messages() {
        wellnessPage.captureErrorMessages();
        wellnessPage.logInvalidFields();
        driver.quit();
    }
}

package com.practo.stepdefinitions;

import com.practo.pages.DiagnosticsPage;
import com.practo.utils.DriverSetup;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;

import java.time.Duration;
import java.util.List;

public class DiagnosticsSteps {
    WebDriver driver;
    DiagnosticsPage diagnosticsPage;

    @Given("I navigate to the diagnostics page")
    public void i_navigate_to_diagnostics_page() {
        driver = DriverSetup.initializeDriver("edge");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.practo.com");

        diagnosticsPage = new DiagnosticsPage(driver);
        diagnosticsPage.navigateToLabTests();
    }

    @Then("I should see a list of top cities")
    public void i_should_see_list_of_top_cities() {
        List<String> cities = diagnosticsPage.getTopCities();
        System.out.println("Top Cities:");
        cities.forEach(System.out::println);
        driver.quit();
    }
}
package com.practo.stepdefinitions;

import com.practo.pages.PractoHospitalScraper;
import com.practo.utils.DriverSetup;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class HospitalSteps {
    WebDriver driver;
    PractoHospitalScraper scraper;

    @Given("I open Practo website")
    public void i_open_practo_website() {
        driver = DriverSetup.initializeDriver("chrome");
        scraper = new PractoHospitalScraper(driver);
    }

    @When("I search for hospitals in Bangalore")
    public void i_search_for_hospitals_in_bangalore() throws InterruptedException {
        scraper.filterAndExtract();
    }

    @Then("I should see hospitals open 24x7 with parking and rating above 3.5")
    public void i_should_see_hospitals_with_required_features() {
        System.out.println("Hospital filtering completed.");
        driver.quit();
    }
}

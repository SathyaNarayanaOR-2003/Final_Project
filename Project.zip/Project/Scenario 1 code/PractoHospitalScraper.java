
package test;

import java.time.Duration;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PractoHospitalScraper {
    static WebDriver driver;
    static boolean allow=false;
    static String mainWindow; 

    public void createDriver() {
        driver = new ChromeDriver();
        driver.get("https://www.practo.com/");
        driver.manage().window().maximize();
    }

    public void filterAndExtract() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));


        WebElement cityInput = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search location']")));
        cityInput.clear();
        cityInput.sendKeys("Bangalore");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[contains(text(),'Bangalore')]")).click();


        WebElement search = driver.findElement(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div/input"));
		search.clear();
		search.sendKeys("Hospital");
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		WebElement hospitalOption = driver.findElement(By.xpath("//*[@id=\"c-omni-container\"]/div/div[2]/div[2]/div[1]/div[4]/span[1]/div"));
		action.moveToElement(hospitalOption).perform();
		Thread.sleep(1000);
		action.click().perform();

        // Wait for results to load
        Thread.sleep(2000);
        mainWindow = driver.getWindowHandle();

        JavascriptExecutor js = (JavascriptExecutor)driver;
        List<WebElement> hospitals247 = driver.findElements(By.xpath("//span[contains(text(),'Open 24x7')]//ancestor::div[2]//h2[@class='line-1']"));
      
        System.out.println("Hospitals that contain parking, rating 3.5, open 24/7:\n");
        for(int i=0;i<hospitals247.size();i++) {

        	filterParking(hospitals247.get(i));
        	driver.switchTo().window(mainWindow);
        }
        Thread.sleep(2000);
        check24x7();
        Thread.sleep(5000);
        
        
        

        closeBrowser();
    }
    public void filterParking(WebElement ele) {
    	String hosp = ele.getText();
    	ele.click();
//    	driver.getTitle();
    	Set<String> windows = driver.getWindowHandles();
    	for (String handle:windows) {
    		if(!handle.equals(mainWindow)) {
    			driver.switchTo().window(handle);
    		}
    	}
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].scrollIntoView(true)",driver.findElement(By.className("bubbles")));
    	WebElement readMore = driver.findElement(By.xpath("//*[@class='pure-u-1']//span/span"));
    	readMore.click();
    	try {
    		Thread.sleep(3000);
    		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Amenities')]")));
    		allow = driver.findElement(By.xpath("//span[contains(text(),'Parking')]")).isDisplayed();
    		if (allow==true) {
    			System.out.println(hosp);
    		}
    		else {
    			System.out.println("Not allowed");
    		}
    		
            driver.close();


    	}
    	catch(Exception e) {


    	}
    }
    public void check24x7(){

    	List<WebElement> hospitals = driver.findElements(By.xpath("//div[contains(@class,'c-estb-info')]"));
        int count = 0;

        for (WebElement hospital : hospitals) {
            if (count >= 30) break;

            try {
                String name = hospital.findElement(By.tagName("h2")).getText();
                String ratingText = hospital.findElement(By.xpath(".//span[contains(@class,'rating') or contains(@class,'u-')][1]")).getText();
                double rating = Double.parseDouble(ratingText);

                if (rating > 3.5) {
                    System.out.println(++count + ". " + name + " (Rating: " + rating + ")");
                }
            } catch (Exception e) {
                // Skip if rating or name not found
            }
        }
    }

    public void closeBrowser() {
        driver.quit();
    }

    public static void main(String[] args) throws InterruptedException {
        PractoHospitalScraper scraper = new PractoHospitalScraper();
        scraper.createDriver();
        scraper.filterAndExtract();
    }
}


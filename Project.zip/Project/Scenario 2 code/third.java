package demo;


import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class third  {
    public static void main(String[] args) {
        WebDriver driver;

        // Setup Edge WebDriver using WebDriverManager
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();

        // Maximize window and set timeouts
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        // Navigate to Practo Corporate Wellness page
        String baseUrl = "https://www.practo.com";
        driver.get(baseUrl);

        // Print page title to confirm
        System.out.println("Page Title: " + driver.getTitle());
        
        WebElement surgeries = driver.findElement(By.xpath("//div[text()='Surgeries']"));
        surgeries.click();
        System.out.println(driver.getTitle());       
        
        WebElement labtests= driver.findElement(By.xpath("//div[text()='Lab Tests']"));
        labtests.click();
        System.out.println(driver.getTitle());  
        
        List<WebElement> cities = driver.findElements(By.cssSelector("ul > li > div.u-margint--standard"));

		System.out.println("Top Cities:");
			for (WebElement city : cities) {
				System.out.println(city.getText());
		}

        // Close browser
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//        driver.quit();
    }
}

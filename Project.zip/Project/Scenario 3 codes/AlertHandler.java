package FinalProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AlertHandler {
    WebDriver driver;

    public AlertHandler(WebDriver driver) {
        this.driver = driver;
    }

    public String getEmailErrorMessage() {
        try {
            return driver.findElement(By.cssSelector("input[name='email'] + span")).getText();
        } catch (Exception e) {
            return "No email error message found.";
        }
    }

    public String getPhoneErrorMessage() {
        try {
            return driver.findElement(By.cssSelector("input[name='phone'] + span")).getText();
        } catch (Exception e) {
            return "No phone error message found.";
        }
    }
}

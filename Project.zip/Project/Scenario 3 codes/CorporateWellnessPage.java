package FinalProject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class CorporateWellnessPage {
    WebDriver driver;
    WebDriverWait wait;

    public CorporateWellnessPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Locators
    By nameField = By.name("name");
    By organizationField = By.name("organizationName");
    By contactField = By.name("contactNumber");
    By emailField = By.name("officialEmailId");
    By sizeDropdown = By.name("organizationSize");
    By interestDropdown = By.name("interestedIn");
    By scheduleButton = By.xpath("//button[contains(text(),'Schedule a demo')]");

    public void fillFormWithInvalidData() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(emailField));
            driver.findElement(nameField).sendKeys("");
            driver.findElement(organizationField).sendKeys("");
            driver.findElement(contactField).sendKeys("7904115");
            driver.findElement(emailField).sendKeys("Sathya@gmail");
        } catch (Exception e) {
            System.out.println("Error filling form: " + e.getMessage());
        }
    }

    public void selectDropdowns() {
        try {
            WebElement sizeDrop = wait.until(ExpectedConditions.elementToBeClickable(sizeDropdown));
            sizeDrop.click();
            sizeDrop.sendKeys("501-1000");

            WebElement interestDrop = wait.until(ExpectedConditions.elementToBeClickable(interestDropdown));
            interestDrop.click();
            interestDrop.sendKeys("Referring someone");
        } catch (Exception e) {
            System.out.println("Error selecting dropdowns: " + e.getMessage());
        }
    }

    public void triggerValidationManually() {
        try {
            driver.findElement(nameField).click();
            driver.findElement(organizationField).click();
            driver.findElement(contactField).click();
            driver.findElement(emailField).click();
            driver.findElement(sizeDropdown).click();
        } catch (Exception e) {
            System.out.println("Error triggering validation: " + e.getMessage());
        }
    }

    public void captureErrorMessages() {
        try {
            List<WebElement> errorMessages = driver.findElements(By.className("error-message"));

            if (errorMessages.isEmpty()) {
                System.out.println("No error messages found.");
            } else {
                for (WebElement error : errorMessages) {
                    System.out.println("Error: " + error.getText());
                }
            }
        } catch (Exception e) {
            System.out.println("Error capturing messages: " + e.getMessage());
        }
    }

    public boolean isScheduleButtonEnabled() {
        try {
            WebElement button = wait.until(ExpectedConditions.presenceOfElementLocated(scheduleButton));
            return button.isEnabled();
        } catch (Exception e) {
            System.out.println("Error checking button state: " + e.getMessage());
            return false;
        }
    }

    public void forceClickScheduleButton() {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("document.querySelector(\"button[disabled]\").removeAttribute('disabled');");
            js.executeScript("document.querySelector(\"button\").click();");
            System.out.println("Forced click on Schedule button.");
        } catch (Exception e) {
            System.out.println("Error forcing button click: " + e.getMessage());
        }
    }

    public void logInvalidFields() {
        try {
            System.out.println("Checking for invalid fields...");

            WebElement name = driver.findElement(nameField);
            WebElement org = driver.findElement(organizationField);
            WebElement contact = driver.findElement(contactField);
            WebElement email = driver.findElement(emailField);

            if (isEmpty(name)) System.out.println("Empty Name");
            if (isEmpty(org)) System.out.println("Empty Organization Name");
            if (isInvalidPhone(contact)) System.out.println("Invalid Contact Number");
            if (isInvalidEmail(email)) System.out.println("Invalid Email ID");

        } catch (Exception e) {
            System.out.println("Error checking invalid fields: " + e.getMessage());
        }
    }

    // Helper to check if a field is empty
    private boolean isEmpty(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || value.trim().isEmpty();
    }

    // Helper to check if phone number is invalid (e.g., less than 10 digits)
    private boolean isInvalidPhone(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || !value.matches("\\d{10}");
    }

    // Helper to check if email is invalid (basic pattern)
    private boolean isInvalidEmail(WebElement element) {
        String value = element.getAttribute("value");
        return value == null || !value.matches("^[\\w.-]+@[\\w.-]+\\.\\w{2,}$");
    }
}

package FinalProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class HomePage {
    WebDriver driver;
    WebDriverWait wait;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Locator for the "For Corporates" menu
    By forCorporatesMenu = By.xpath("//span[text()='For Corporates']");

    // Locator for the first dropdown option: "Health & Wellness Plans"
    By healthWellnessOption = By.xpath("//a[contains(text(),'Health & Wellness Plans')]");

    public void goToCorporateWellness() {
        Actions actions = new Actions(driver);

        // Hover over "For Corporates" image text
        WebElement menu = wait.until(ExpectedConditions.visibilityOfElementLocated(forCorporatesMenu));
        actions.moveToElement(menu).click().perform(); // Hover and click

        // Wait for the dropdown option to be clickable
        WebElement firstOption = wait.until(ExpectedConditions.elementToBeClickable(healthWellnessOption));
        firstOption.click();
    }
}

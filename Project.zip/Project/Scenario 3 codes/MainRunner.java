package FinalProject;

import org.openqa.selenium.WebDriver;

public class MainRunner {
    public static void main(String[] args) {
        // Initialize WebDriver
        WebDriver driver = DriverSetup.initializeDriver("chrome"); // or "edge"

        try {
            // Navigate to Practo
            driver.get("https://www.practo.com");

            // Navigate to Corporate Wellness section
            HomePage home = new HomePage(driver);
            home.goToCorporateWellness();

            // Interact with the Corporate Wellness form
            CorporateWellnessPage wellness = new CorporateWellnessPage(driver);
            wellness.fillFormWithInvalidData();     // Fill invalid inputs
            wellness.selectDropdowns();             // Select dropdown values
            wellness.triggerValidationManually();   // Trigger blur validation
            wellness.captureErrorMessages();        // Capture inline errors
            wellness.forceClickScheduleButton();    // Force click even if disabled
            wellness.logInvalidFields();            // Log which fields are invalid

        } catch (Exception e) {
            System.out.println("An error occurred during execution: " + e.getMessage());
        } finally {
            // Quit the browser
            if (driver != null) {
                driver.quit();
            }
        }
    }
}
